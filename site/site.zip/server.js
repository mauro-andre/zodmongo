import { Fragment, jsx, jsxs } from "preact/jsx-runtime";
import { Link, Scripts } from "@mauroandre/velojs";
import { useLoader, useParams, usePathname } from "@mauroandre/velojs/hooks";
import { useSignal } from "@preact/signals";
import { startServer } from "@mauroandre/velojs/server";
//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
//#endregion
//#region app/client-root.tsx
var client_root_exports = /* @__PURE__ */ __exportAll({
	Component: () => Component$3,
	metadata: () => metadata$3
});
var metadata$3 = {
	moduleId: "client-root",
	fullPath: "",
	path: ""
};
var Component$3 = ({ children }) => {
	return /* @__PURE__ */ jsxs("html", {
		lang: "en",
		children: [/* @__PURE__ */ jsxs("head", { children: [
			/* @__PURE__ */ jsx("meta", { charSet: "utf-8" }),
			/* @__PURE__ */ jsx("meta", {
				name: "viewport",
				content: "width=device-width, initial-scale=1.0"
			}),
			/* @__PURE__ */ jsx("title", { children: "ZodMongo — Lightweight MongoDB ODM with Zod" }),
			/* @__PURE__ */ jsx("meta", {
				name: "description",
				content: "Lightweight MongoDB ODM powered by Zod schemas. TypeScript-first, built on the native MongoDB driver. No Mongoose."
			}),
			/* @__PURE__ */ jsx("link", {
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			}),
			/* @__PURE__ */ jsx("link", {
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			}),
			/* @__PURE__ */ jsx("link", {
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap",
				rel: "stylesheet"
			}),
			/* @__PURE__ */ jsx(Scripts, {})
		] }), /* @__PURE__ */ jsx("body", { children })]
	});
};
//#endregion
//#region app/scarlab-icons.tsx
var ChartBar = (props) => /* @__PURE__ */ jsxs("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 24 24",
	width: props.size ?? 32,
	height: props.size ?? 32,
	fill: "none",
	...props,
	children: [
		/* @__PURE__ */ jsx("path", {
			d: "M12 7L12 21",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M17 3L17 21",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M7 10L7 21",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	]
});
var Code = (props) => /* @__PURE__ */ jsxs("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 24 24",
	width: props.size ?? 32,
	height: props.size ?? 32,
	fill: "none",
	...props,
	children: [/* @__PURE__ */ jsx("path", {
		d: "M17 15L19.6462 12.3538V12.3538C19.8416 12.1584 19.8416 11.8416 19.6462 11.6462V11.6462L17 9",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round"
	}), /* @__PURE__ */ jsx("path", {
		d: "M7 9L4.35151 11.6485V11.6485C4.15738 11.8426 4.15738 12.1574 4.35151 12.3515V12.3515L7 15",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round"
	})]
});
var Database = (props) => /* @__PURE__ */ jsxs("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 24 24",
	width: props.size ?? 32,
	height: props.size ?? 32,
	fill: "none",
	...props,
	children: [
		/* @__PURE__ */ jsx("path", {
			d: "M20 7C20 9.20914 16.4183 11 12 11C7.58172 11 4 9.20914 4 7C4 4.79086 7.58172 3 12 3C16.4183 3 20 4.79086 20 7Z",
			stroke: "currentColor",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M20 12C20 14.2091 16.4183 16 12 16C7.58172 16 4 14.2091 4 12",
			stroke: "currentColor",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M4 7V17C4 19.2091 7.58172 21 12 21C16.4183 21 20 19.2091 20 17V7",
			stroke: "currentColor",
			strokeWidth: "2"
		})
	]
});
var Link$1 = (props) => /* @__PURE__ */ jsxs("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 24 24",
	width: props.size ?? 32,
	height: props.size ?? 32,
	fill: "none",
	...props,
	children: [
		/* @__PURE__ */ jsx("path", {
			d: "M9 8L7 8C5.11438 8 4.17157 8 3.58578 8.58579C3 9.17158 3 10.1144 3 12V12C3 13.8856 3 14.8284 3.58579 15.4142C4.17157 16 5.11438 16 7 16L9 16",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M15 16L17 16C18.8856 16 19.8284 16 20.4142 15.4142C21 14.8284 21 13.8856 21 12V12C21 10.1144 21 9.17157 20.4142 8.58578C19.8284 8 18.8856 8 17 8L15 8",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M8 12H16",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	]
});
var SwitchHorizontal = (props) => /* @__PURE__ */ jsxs("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 24 24",
	width: props.size ?? 32,
	height: props.size ?? 32,
	fill: "none",
	...props,
	children: [
		/* @__PURE__ */ jsx("path", {
			d: "M21 9L9 9",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M15 15L3 15",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M18 12L20.913 9.08704V9.08704C20.961 9.03897 20.961 8.96103 20.913 8.91296V8.91296L18 6",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M6 18L3.08704 15.087V15.087C3.03897 15.039 3.03897 14.961 3.08704 14.913V14.913L6 12",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	]
});
var Terminal = (props) => /* @__PURE__ */ jsxs("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 24 24",
	width: props.size ?? 32,
	height: props.size ?? 32,
	fill: "none",
	...props,
	children: [
		/* @__PURE__ */ jsx("path", {
			d: "M13 15H16",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M8 15L10.5 12.5V12.5C10.7761 12.2239 10.7761 11.7761 10.5 11.5V11.5L8 9",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ jsx("path", {
			d: "M3 8C3 6.11438 3 5.17157 3.58579 4.58579C4.17157 4 5.11438 4 7 4H12H17C18.8856 4 19.8284 4 20.4142 4.58579C21 5.17157 21 6.11438 21 8V12V16C21 17.8856 21 18.8284 20.4142 19.4142C19.8284 20 18.8856 20 17 20H12H7C5.11438 20 4.17157 20 3.58579 19.4142C3 18.8284 3 17.8856 3 16V12V8Z",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinejoin: "round"
		})
	]
});
//#endregion
//#region app/Landing.css.ts
var page = "jktud50";
var nav = "jktud51";
var navInner = "jktud52";
var logo = "jktud53";
var navLinks = "jktud54";
var navLink = "jktud55";
var navCta = "jktud56";
var hero = "jktud57";
var heroTitle = "jktud58";
var heroTagline = "jktud59";
var heroSubtitle = "jktud5a";
var heroActions = "jktud5b";
var btnPrimary = "jktud5c";
var btnSecondary = "jktud5d";
var section = "jktud5e";
var sectionTitle = "jktud5f";
var sectionSubtitle = "jktud5g";
var featuresGrid = "jktud5h";
var featureCard = "jktud5i";
var featureIcon = "jktud5j";
var featureTitle = "jktud5k";
var featureDesc = "jktud5l";
var installSection = "jktud5m";
var installCode = "jktud5n";
var footer = "jktud5o";
var footerInner = "jktud5p";
var footerLinks = "jktud5q";
var footerLink = "jktud5r";
var footerCopyright = "jktud5s";
//#endregion
//#region app/Landing.tsx
var Landing_exports = /* @__PURE__ */ __exportAll({
	Component: () => Component$2,
	metadata: () => metadata$2
});
var metadata$2 = {
	moduleId: "Landing",
	fullPath: "/",
	path: "/"
};
var features = [
	{
		Icon: Code,
		title: "Zod-Native Schemas",
		desc: "Define your models with Zod. Types are inferred automatically. No proprietary schema format, no decorators."
	},
	{
		Icon: Database,
		title: "Native MongoDB Driver",
		desc: "Built directly on the official MongoDB driver. No Mongoose overhead, no hidden abstractions. Just fast, direct access."
	},
	{
		Icon: Terminal,
		title: "TypeScript-First",
		desc: "Full type inference from your Zod schemas. Autocomplete for queries, documents, and pagination — everywhere."
	},
	{
		Icon: Link$1,
		title: "Relations & Lookups",
		desc: "Declare references between collections. The ODM generates $lookup pipelines automatically from your schema."
	},
	{
		Icon: ChartBar,
		title: "Built-in Pagination",
		desc: "Paginated queries via $facet in a single aggregation call. Page metadata included — no extra count query."
	},
	{
		Icon: SwitchHorizontal,
		title: "Transparent id/ObjectId",
		desc: "Work with id (string) in your app, _id (ObjectId) in MongoDB. Bidirectional conversion is automatic and recursive."
	}
];
var Component$2 = () => {
	return /* @__PURE__ */ jsxs("div", {
		class: page,
		children: [
			/* @__PURE__ */ jsx("nav", {
				class: nav,
				children: /* @__PURE__ */ jsxs("div", {
					class: navInner,
					children: [/* @__PURE__ */ jsx("span", {
						class: logo,
						children: "ZodMongo"
					}), /* @__PURE__ */ jsxs("div", {
						class: navLinks,
						children: [
							/* @__PURE__ */ jsx(Link, {
								to: "/docs/getting-started",
								class: navLink,
								children: "Docs"
							}),
							/* @__PURE__ */ jsx("a", {
								href: "https://github.com/mauro-andre/zodmongo",
								target: "_blank",
								class: navLink,
								children: "GitHub"
							}),
							/* @__PURE__ */ jsx("a", {
								href: "https://www.npmjs.com/package/zodmongo",
								target: "_blank",
								class: navLink,
								children: "npm"
							}),
							/* @__PURE__ */ jsx(Link, {
								to: "/docs/getting-started",
								class: navCta,
								children: "Get Started"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ jsxs("section", {
				class: hero,
				children: [
					/* @__PURE__ */ jsx("h1", {
						class: heroTitle,
						children: "ZodMongo"
					}),
					/* @__PURE__ */ jsx("p", {
						class: heroTagline,
						children: "Lightweight MongoDB ODM with Zod validation"
					}),
					/* @__PURE__ */ jsx("p", {
						class: heroSubtitle,
						children: "TypeScript-first ODM built on the native MongoDB driver. Define schemas with Zod, get automatic id conversion, timestamps, pagination, and relation lookups — in ~300 lines."
					}),
					/* @__PURE__ */ jsxs("div", {
						class: heroActions,
						children: [/* @__PURE__ */ jsx(Link, {
							to: "/docs/getting-started",
							class: btnPrimary,
							children: "Get Started"
						}), /* @__PURE__ */ jsx("a", {
							href: "https://github.com/mauro-andre/zodmongo",
							target: "_blank",
							class: btnSecondary,
							children: "View on GitHub"
						})]
					})
				]
			}),
			/* @__PURE__ */ jsxs("section", {
				class: installSection,
				children: [/* @__PURE__ */ jsx("h2", {
					class: sectionTitle,
					children: "Get started in seconds"
				}), /* @__PURE__ */ jsx("code", {
					class: installCode,
					children: "npm install @mauroandre/zodmongo"
				})]
			}),
			/* @__PURE__ */ jsxs("section", {
				class: section,
				children: [
					/* @__PURE__ */ jsx("h2", {
						class: sectionTitle,
						children: "Everything you need"
					}),
					/* @__PURE__ */ jsx("p", {
						class: sectionSubtitle,
						children: "A focused ODM that handles schemas, queries, relations, and pagination — so you can skip the boilerplate."
					}),
					/* @__PURE__ */ jsx("div", {
						class: featuresGrid,
						children: features.map((f, i) => /* @__PURE__ */ jsxs("div", {
							class: featureCard,
							children: [
								/* @__PURE__ */ jsx("span", {
									class: featureIcon,
									children: /* @__PURE__ */ jsx(f.Icon, { size: 28 })
								}),
								/* @__PURE__ */ jsx("h3", {
									class: featureTitle,
									children: f.title
								}),
								/* @__PURE__ */ jsx("p", {
									class: featureDesc,
									children: f.desc
								})
							]
						}, i))
					})
				]
			}),
			/* @__PURE__ */ jsx("footer", {
				class: footer,
				children: /* @__PURE__ */ jsxs("div", {
					class: footerInner,
					children: [
						/* @__PURE__ */ jsx("span", {
							class: logo,
							children: "ZodMongo"
						}),
						/* @__PURE__ */ jsxs("div", {
							class: footerLinks,
							children: [
								/* @__PURE__ */ jsx(Link, {
									to: "/docs/getting-started",
									class: footerLink,
									children: "Docs"
								}),
								/* @__PURE__ */ jsx("a", {
									href: "https://github.com/mauro-andre/zodmongo",
									target: "_blank",
									class: footerLink,
									children: "GitHub"
								}),
								/* @__PURE__ */ jsx("a", {
									href: "https://www.npmjs.com/package/zodmongo",
									target: "_blank",
									class: footerLink,
									children: "npm"
								})
							]
						}),
						/* @__PURE__ */ jsx("p", {
							class: footerCopyright,
							children: "© 2026 Mauro André. MIT License."
						})
					]
				})
			})
		]
	});
};
//#endregion
//#region app/docs/Layout.css.ts
var layout = "_1273p6o0";
var sidebar = "_1273p6o1";
var sidebarVisible = "_1273p6o2";
var sidebarHeader = "_1273p6o3";
var sidebarLogo = "_1273p6o4";
var sidebarNav = "_1273p6o5";
var sidebarLink = "_1273p6o6";
var sidebarLinkActive = "_1273p6o7";
var mobileToggle = "_1273p6o8";
var content = "_1273p6o9";
var contentHeader = "_1273p6oa";
var contentTitle = "_1273p6ob";
var prevNext = "_1273p6od";
var prose = "_1273p6oh";
//#endregion
//#region app/docs/Layout.tsx
var Layout_exports = /* @__PURE__ */ __exportAll({
	Component: () => Component$1,
	loader: () => loader$1,
	metadata: () => metadata$1
});
var metadata$1 = {
	moduleId: "docs/Layout",
	fullPath: "/docs",
	path: "/docs"
};
var loader$1 = async ({}) => {
	const { default: manifest } = await import("./assets/_virtual_docs-manifest-BuslhfFg.js");
	return { manifest };
};
var Component$1 = ({ children }) => {
	const sidebarOpen = useSignal(false);
	const pathname = usePathname();
	const { data } = useLoader("docs/Layout", [pathname]);
	const entries = data.value?.manifest ?? [];
	return /* @__PURE__ */ jsxs("div", {
		class: layout,
		children: [
			/* @__PURE__ */ jsx("button", {
				class: mobileToggle,
				onClick: () => sidebarOpen.value = !sidebarOpen.value,
				children: sidebarOpen.value ? "✕" : "☰"
			}),
			/* @__PURE__ */ jsxs("aside", {
				class: `${sidebar} ${sidebarOpen.value ? sidebarVisible : ""}`,
				children: [/* @__PURE__ */ jsx("div", {
					class: sidebarHeader,
					children: /* @__PURE__ */ jsx(Link, {
						to: "~/",
						class: sidebarLogo,
						children: "ZodMongo"
					})
				}), /* @__PURE__ */ jsx("nav", {
					class: sidebarNav,
					children: entries.map((entry) => /* @__PURE__ */ jsx(Link, {
						to: `/${entry.slug}`,
						class: `${sidebarLink} ${pathname === `/docs/${entry.slug}` ? sidebarLinkActive : ""}`,
						children: entry.title
					}, entry.slug))
				})]
			}),
			/* @__PURE__ */ jsx("main", {
				class: content,
				children
			})
		]
	});
};
//#endregion
//#region app/docs/DocPage.tsx
var DocPage_exports = /* @__PURE__ */ __exportAll({
	Component: () => Component,
	loader: () => loader,
	metadata: () => metadata,
	staticPaths: () => staticPaths
});
var metadata = {
	moduleId: "docs/DocPage",
	fullPath: "/docs/:slug",
	path: "/:slug"
};
var staticPaths = async () => {
	const { default: manifest } = await import("./assets/_virtual_docs-manifest-BuslhfFg.js");
	return manifest.map((entry) => ({ slug: entry.slug }));
};
var loader = async ({ params }) => {
	const { default: manifest } = await import("./assets/_virtual_docs-manifest-BuslhfFg.js");
	const { default: content } = await import("./assets/_virtual_docs-content-B-g6EjE8.js");
	const slug = params.slug;
	const doc = content[slug];
	const entry = manifest.find((m) => m.slug === slug);
	const index = manifest.findIndex((m) => m.slug === slug);
	const prev = index > 0 ? manifest[index - 1] : null;
	const next = index < manifest.length - 1 ? manifest[index + 1] : null;
	return {
		html: doc?.html ?? "",
		title: entry?.title ?? slug,
		filename: entry?.filename ?? "",
		prevSlug: prev?.slug ?? null,
		prevTitle: prev?.title ?? null,
		nextSlug: next?.slug ?? null,
		nextTitle: next?.title ?? null
	};
};
var Component = () => {
	const { data } = useLoader("docs/DocPage", [useParams().slug]);
	if (!data.value) return null;
	const { html, title, filename, prevSlug, prevTitle, nextSlug, nextTitle } = data.value;
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsxs("div", {
			class: contentHeader,
			children: [/* @__PURE__ */ jsx("h1", {
				class: contentTitle,
				children: title
			}), filename && /* @__PURE__ */ jsx("a", {
				href: `/docs/${filename}`,
				download: true,
				class: "_1273p6oc",
				children: "Download .md"
			})]
		}),
		/* @__PURE__ */ jsx("div", {
			class: prose,
			dangerouslySetInnerHTML: { __html: html }
		}),
		/* @__PURE__ */ jsxs("div", {
			class: prevNext,
			children: [/* @__PURE__ */ jsx("div", { children: prevSlug && /* @__PURE__ */ jsxs(Link, {
				to: `/${prevSlug}`,
				class: "_1273p6oe",
				children: [/* @__PURE__ */ jsx("span", {
					class: "_1273p6of",
					children: "Previous"
				}), /* @__PURE__ */ jsx("span", {
					class: "_1273p6og",
					children: prevTitle
				})]
			}) }), /* @__PURE__ */ jsx("div", { children: nextSlug && /* @__PURE__ */ jsxs(Link, {
				to: `/${nextSlug}`,
				class: "_1273p6oe",
				style: { textAlign: "right" },
				children: [/* @__PURE__ */ jsx("span", {
					class: "_1273p6of",
					children: "Next"
				}), /* @__PURE__ */ jsx("span", {
					class: "_1273p6og",
					children: nextTitle
				})]
			}) })]
		})
	] });
};
//#endregion
//#region app/routes.tsx
var routes_default = [{
	module: client_root_exports,
	isRoot: true,
	children: [{
		path: "/",
		module: Landing_exports
	}, {
		path: "/docs",
		module: Layout_exports,
		children: [{
			path: "/:slug",
			module: DocPage_exports
		}]
	}]
}];
//#endregion
//#region \0virtual:velo/server-entry
var server_entry_default = await startServer({ routes: routes_default });
//#endregion
export { server_entry_default as default, routes_default as routes };
