//#region \0virtual:docs-manifest
var _virtual_docs_manifest_default = [
	{
		"slug": "getting-started",
		"title": "Getting Started",
		"order": 1,
		"filename": "01-getting-started.md"
	},
	{
		"slug": "schemas",
		"title": "Schemas",
		"order": 2,
		"filename": "02-schemas.md"
	},
	{
		"slug": "save",
		"title": "Save",
		"order": 3,
		"filename": "03-save.md"
	},
	{
		"slug": "queries",
		"title": "Queries",
		"order": 4,
		"filename": "04-queries.md"
	},
	{
		"slug": "pagination",
		"title": "Pagination",
		"order": 5,
		"filename": "05-pagination.md"
	},
	{
		"slug": "delete",
		"title": "Delete",
		"order": 6,
		"filename": "06-delete.md"
	},
	{
		"slug": "relations",
		"title": "Relations",
		"order": 7,
		"filename": "07-relations.md"
	},
	{
		"slug": "snapshots",
		"title": "Snapshots",
		"order": 8,
		"filename": "08-snapshots.md"
	},
	{
		"slug": "connection",
		"title": "Connection",
		"order": 9,
		"filename": "09-connection.md"
	},
	{
		"slug": "why-zodmongo",
		"title": "Why ZodMongo",
		"order": 10,
		"filename": "10-why-zodmongo.md"
	}
];
//#endregion
export { _virtual_docs_manifest_default as default };
